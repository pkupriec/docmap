# Service Contracts

This document defines the responsibilities, inputs, outputs, persistence behavior, and failure handling rules for the core DocMap services.

The purpose of this file is to prevent architectural drift during AI-assisted development.

---

# Overview

Core services:

1. crawler
2. extractor
3. geocoder
4. pipeline
5. analytics exporter

These services must remain logically separated even if some are deployed together in early MVP stages.

---

# 1. Crawler

## Responsibility

The crawler is responsible for:

- discovering SCP document URLs
- downloading SCP Wiki pages
- extracting raw HTML
- generating cleaned text
- generating PDF snapshots
- storing document snapshots in the database

The crawler does NOT:

- call the LLM
- geocode locations
- write analytics tables
- export to BigQuery

## Inputs

Crawler input is one of:

- a generated SCP identifier range, such as `SCP-001` to `SCP-7999`
- a single document URL
- a list of URLs
- a scheduled update job requesting changed documents only

## Outputs

The crawler must produce:

- `documents` records
- `document_snapshots` records

Snapshot output must include:

- `raw_html`
- `clean_text`
- `pdf_path`
- timestamp

## Database writes

The crawler may write only to:

- `scp_objects`
- `documents`
- `document_snapshots`

The crawler must not write to:

- `extraction_runs`
- `location_mentions`
- `geo_locations`
- `document_locations`
- BI tables

## Idempotency expectations

Running the crawler twice on the same unchanged document must not create inconsistent duplicate logical records.

A new snapshot should be created only when:

- the document is first seen
- the document content changed
- an explicit re-snapshot operation was requested

## Failure handling

Crawler failures must be isolated at document level.

If one document fails:

- log the error
- retry according to retry policy
- continue processing other documents

The crawler must never stop the whole corpus job because of a single bad page.

## Retry policy

Minimum expected behavior:

- 3 retries
- exponential backoff
- timeout on HTTP requests

## Rate limiting

The crawler must implement request throttling to avoid overloading the source site.

## Suggested Python contract

Example interface:

```python
def generate_scp_urls(start: int, end: int) -> list[str]: ...
def download_page(url: str) -> str: ...
def extract_clean_text(raw_html: str) -> str: ...
def render_pdf(url: str, output_path: str) -> str: ...
def save_snapshot(document_url: str, raw_html: str, clean_text: str, pdf_path: str) -> str: ...

2. Extractor
Responsibility

The extractor is responsible for:

reading document snapshots

sending cleaned text to the LLM

extracting geographic mentions

validating JSON output

storing extraction runs

storing location mentions

The extractor does NOT:

download HTML

geocode places

export analytics

update BI tables directly

Inputs

Extractor input is:

a document_snapshot

optionally a selected model name

prompt version

pipeline version

Main logical input:

clean_text

Outputs

The extractor must produce:

one extraction_runs record per extraction invocation

zero or more location_mentions

Each mention must include:

mention_text

normalized_location

precision

relation_type

confidence

evidence_quote

Database writes

The extractor may write only to:

extraction_runs

location_mentions

The extractor must not write to:

geo_locations

document_locations

BI tables

JSON contract

LLM output must be valid JSON and must match this structure:

{
  "locations": [
    {
      "mention_text": "...",
      "normalized_location": "...",
      "precision": "city|admin_region|country|coordinates|unknown",
      "relation_type": "unspecified",
      "confidence": 0.0,
      "evidence_quote": "..."
    }
  ]
}
Validation rules

Extractor must reject or retry if:

response is not valid JSON

locations key is missing

required fields are missing

confidence is not numeric

JSON is malformed

Failure handling

If extraction fails for one snapshot:

record the failed run if appropriate

log the error

optionally retry

continue with the next snapshot

A single extraction failure must not terminate the batch.

Retry policy

At minimum:

retry invalid JSON responses

retry transient Ollama/network failures

cap retries

Suggested Python contract
def build_extraction_prompt(text: str) -> str: ...
def run_extraction(model: str, text: str) -> dict: ...
def validate_extraction_response(payload: dict) -> dict: ...
def save_extraction_run(snapshot_id: str, model: str, prompt_version: str, pipeline_version: str) -> str: ...
def save_location_mentions(run_id: str, payload: dict) -> int: ...
3. Geocoder
Responsibility

The geocoder is responsible for:

reading normalized locations

resolving them through Nominatim

storing geocoded locations

linking mentions/documents to geocoded locations

The geocoder does NOT:

crawl documents

call the LLM for extraction

generate BI tables

export to BigQuery

LLM-based normalization may exist as a separate internal helper, but extraction and geocoding remain separate stages.

Inputs

Geocoder input is:

normalized_location strings from location_mentions

optionally unresolved mention records only

Outputs

The geocoder must produce:

geo_locations records

document_locations link records

Geocoder output should include:

latitude

longitude

country

region

city

precision

geometry value

Database writes

The geocoder may write only to:

geo_locations

document_locations

It may read from:

location_mentions

extraction_runs

documents

document_snapshots

Caching expectations

Geocoder must reuse previously geocoded normalized locations when possible.

It should avoid repeated external API calls for identical normalized strings unless refresh is explicitly requested.

Failure handling

If a location cannot be geocoded:

log the failure

optionally mark it unresolved

continue processing remaining locations

If the geocoder service is temporarily unavailable:

retry

continue later without corrupting prior data

Suggested Python contract
def geocode_location(name: str) -> dict | None: ...
def normalize_geocoder_response(payload: dict) -> dict: ...
def save_geo_location(location: dict) -> str: ...
def link_document_location(document_id: str, location_id: str, mention_id: str) -> str: ...
4. Pipeline
Responsibility

The pipeline service is the orchestrator.

It is responsible for:

sequencing crawl → extract → geocode → analytics → export

selecting which documents to process

coordinating incremental and weekly jobs

managing job boundaries

reporting status

The pipeline does NOT:

contain the business logic of crawling

contain the business logic of extraction

contain the business logic of geocoding

It delegates to the dedicated services.

Inputs

Pipeline input may be:

full corpus run

incremental update run

single-document debug run

weekly scheduled run

Outputs

The pipeline produces:

execution progress

service invocations

success/failure summaries

updated downstream datasets

Persistence behavior

The pipeline itself should write minimal orchestration metadata unless a dedicated jobs table is later added.

At minimum, it must not duplicate domain data already owned by other services.

Failure handling

The pipeline must support partial completion.

If one stage fails:

preserve completed upstream data

allow reruns from the failed stage

avoid redoing unchanged work unnecessarily

Suggested orchestration phases

discover targets

crawl targets

select snapshots needing extraction

run extraction

select unresolved mentions

run geocoding

rebuild analytics layer

export analytics to BigQuery

Suggested Python contract
def run_full_pipeline() -> None: ...
def run_incremental_pipeline() -> None: ...
def run_single_document_pipeline(url: str) -> None: ...
def rebuild_analytics() -> None: ...
def export_bigquery() -> None: ...
5. Analytics Exporter
Responsibility

The analytics exporter is responsible for:

building BI-facing tables or views

preparing export-ready datasets

pushing data to BigQuery

The analytics exporter does NOT:

crawl SCP Wiki

call the LLM

geocode locations

Inputs

Analytics exporter input is:

normalized operational tables from Postgres/PostGIS

Main read sources:

documents

document_snapshots

location_mentions

geo_locations

document_locations

Outputs

Analytics exporter must produce:

bi_documents

bi_locations

bi_document_locations

and then export them into BigQuery target tables.

Database writes

Inside Postgres it may write to:

BI tables

BI materialized views if later adopted

It must not mutate crawler/extractor/geocoder source data.

Failure handling

If export to BigQuery fails:

keep local BI tables intact

log the failure

allow retry without rebuilding the entire corpus pipeline

Suggested Python contract
def build_bi_documents() -> int: ...
def build_bi_locations() -> int: ...
def build_bi_document_locations() -> int: ...
def export_table_to_bigquery(table_name: str) -> None: ...
Cross-Service Rules
Ownership

Each service owns a narrow write scope.

No service should write into another service's domain tables unless explicitly defined here.

Sequence

The expected default order is:

crawler

extractor

geocoder

analytics exporter

Pipeline orchestrates this order.

Reprocessing

The architecture must support:

re-crawling documents

re-running extraction on existing snapshots

re-running geocoding on unresolved locations

rebuilding BI/export layers independently

Determinism

Where possible:

use explicit inputs

use validated outputs

log failures

avoid hidden side effects

MVP principle

Keep services simple, but keep boundaries clear.