# Phase 2 — SCP Crawler

Goal: download SCP documents.

Tasks:

2.1 Implement SCP URL generator

scp-001
scp-002
...
scp-7999

---

2.2 Implement HTML downloader

GET https://scp-wiki.wikidot.com/scp-XXXX

---

2.3 Parse article HTML

Use BeautifulSoup.

---

2.4 Extract main article content

Remove:

navigation
sidebar
CSS

---

2.5 Store raw_html in database

---

2.6 Generate clean_text

---

2.7 Generate PDF snapshot

Use wkhtmltopdf.

---

2.8 Save snapshot record

Insert into document_snapshots.

---

2.9 Add retry logic

---

2.10 Add rate limiting

Avoid overloading SCP Wiki.

---

2.11 Implement incremental updates

Check for page changes weekly.