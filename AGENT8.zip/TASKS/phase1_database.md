# Phase 1 — Database Layer

Goal: implement database schema.

Tasks:

1.1 Enable extensions

postgis
vector

---

1.2 Create table: scp_objects

---

1.3 Create table: documents

---

1.4 Create table: document_snapshots

---

1.5 Create table: extraction_runs

---

1.6 Create table: location_mentions

---

1.7 Create table: geo_locations

---

1.8 Create table: document_locations

---

1.9 Create analytics tables

bi_documents
bi_locations
bi_document_locations

---

1.10 Create spatial index

geo_locations.geom

---

1.11 Create useful indexes

documents(scp_id)
location_mentions(run_id)
document_locations(document_id)

---

1.12 Create seed script

Insert SCP IDs:

SCP-001 → SCP-7999