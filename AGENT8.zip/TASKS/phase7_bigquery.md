# Phase 7 — BigQuery Export

Goal: export analytics data.

Tasks:

7.1 Create BigQuery dataset

---

7.2 Implement export pipeline

---

7.3 Convert Postgres data to BigQuery format

---

7.4 Upload analytics tables

---

7.5 Implement incremental export