# Phase 0 — Project Bootstrap

This phase prepares the development environment and repository structure.

The goal is to create a stable foundation before implementing core services.

No crawling, extraction, or geocoding logic should be implemented in this phase.

---

# Step 1 — Python Project Setup

Create Python project configuration.

Create file:


pyproject.toml


Example minimal configuration:


[project]
name = "docmap"
version = "0.1.0"
requires-python = ">=3.11"

dependencies = [
"fastapi",
"requests",
"psycopg[binary]",
"pydantic",
"python-dotenv",
]


---

# Step 2 — Repository Layout

Ensure the following directory structure exists:


services/
crawler/
extractor/
geocoder/
pipeline/
analytics/

database/
infra/
tests/


Create empty `__init__.py` files in each Python module directory.

---

# Step 3 — Environment Configuration

Create file:


.env.example


Example contents:


DATABASE_URL=postgresql://docmap:docmap@postgres:5432/docmap
OLLAMA_HOST=http://host.docker.internal:11434

GEOCODER_URL=https://nominatim.openstreetmap.org


---

# Step 4 — Basic Logging Setup

Create module:


services/common/logging.py


Example function:


import logging

def configure_logging():
logging.basicConfig(
level=logging.INFO,
format="%(asctime)s %(levelname)s %(name)s %(message)s"
)


All services must import and use this configuration.

---

# Step 5 — Database Connection Utility

Create module:


services/common/db.py


Example:


import psycopg

def get_connection():
return psycopg.connect()


Use environment variable `DATABASE_URL`.

---

# Step 6 — Base Application Entrypoint

Create file:


main.py


Example structure:


def main():
print("DocMap bootstrap successful")

if name == "main":
main()


---

# Step 7 — Basic Test Setup

Create directory:


tests/


Add example test:


tests/test_bootstrap.py


Example:


def test_bootstrap():
assert True


Use `pytest` as the testing framework.

---

# Step 8 — Docker Verification

Verify that the system can start:


docker compose up


Confirm:

- PostgreSQL starts
- schema initializes
- application container runs

---

# Definition of Done

Phase 0 is complete when:

- Python project structure exists
- dependencies install successfully
- Docker environment starts
- database schema loads
- basic tests run