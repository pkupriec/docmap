# Phase 8 — Scheduler

Goal: automate weekly pipeline.

Tasks:

8.1 Implement scheduler

Use cron.

---

8.2 Weekly crawl job

---

8.3 Weekly extraction job

---

8.4 Weekly geocode job

---

8.5 Weekly analytics export