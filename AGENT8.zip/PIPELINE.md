# Processing Pipeline

This document describes the operational sequence of DocMap, including stage responsibilities, persistence points, failure behavior, and weekly update flow.

The goal is to define a stable execution model for both human developers and AI coding agents.

---

# Pipeline Goal

Transform SCP Wiki pages into analytics-ready geographic document mappings.

Input:

- SCP Wiki numbered SCP articles in English

Output:

- BI datasets exported to BigQuery for Looker Studio map visualization

---

# End-to-End Sequence

The default end-to-end flow is:

1. target discovery
2. crawl
3. snapshot persistence
4. extraction
5. extraction persistence
6. geocoding
7. geocoding persistence
8. analytics rebuild
9. BigQuery export

---

# Stage 1 — Target Discovery

## Responsibility

Determine which SCP documents should be processed.

## Inputs

Possible inputs:

- configured SCP number range
- existing document inventory
- update schedule
- manual single-document request

## Outputs

A list of target SCP URLs or document identities to process.

## Persistence

This stage does not need to persist domain data in MVP.

## Failure handling

If some targets cannot be resolved:

- log them
- continue with the rest

---

# Stage 2 — Crawl

## Responsibility

Fetch the source page and derive the raw document artifacts.

## Inputs

- SCP document URL

## Actions

- download HTML
- keep raw HTML
- derive cleaned text
- render PDF snapshot

## Outputs

A complete document snapshot payload:

- raw_html
- clean_text
- pdf_path
- timestamp

## Persistence point

Write to:

- `documents`
- `document_snapshots`

## Failure handling

If download or parsing fails:

- retry
- log failure
- continue with remaining pages

A single bad document must not fail the batch.

---

# Stage 3 — Snapshot Persistence

## Responsibility

Persist the exact version of the crawled document.

## Inputs

- crawler artifact payload

## Outputs

- one immutable snapshot record

## Persistence point

Write to:

- `document_snapshots`

## Why this matters

This stage enables:

- exact reproducibility
- extraction reruns without re-downloading
- historical comparison

---

# Stage 4 — Extraction

## Responsibility

Extract real geographic location mentions using the LLM.

## Inputs

- `clean_text`
- extraction prompt
- model
- prompt version
- pipeline version

## Actions

- build prompt
- invoke LLM
- parse JSON
- validate structure

## Outputs

Validated extraction payload:

```json
{
  "locations": [
    {
      "mention_text": "...",
      "normalized_location": "...",
      "precision": "...",
      "relation_type": "unspecified",
      "confidence": 0.0,
      "evidence_quote": "..."
    }
  ]
}

Persistence point

Write to:

extraction_runs

location_mentions

Failure handling

If JSON is invalid or model call fails:

retry when appropriate

log failure

continue processing other snapshots

Snapshots must remain reusable even if extraction fails.

Stage 5 — Extraction Persistence
Responsibility

Store extraction lineage and mention-level facts.

Inputs

validated extraction payload

snapshot metadata

Outputs

extraction run record

zero or more mention records

Persistence point

Write to:

extraction_runs

location_mentions

Why this matters

This stage separates:

source preservation

model behavior

geocoding behavior

That separation is essential for reruns and debugging.

Stage 6 — Geocoding
Responsibility

Resolve normalized locations into real-world geographic coordinates and metadata.

Inputs

normalized_location values from location_mentions

Actions

look up cached geocode results if available

query Nominatim if unresolved

normalize geocoder response

assign geometry

Outputs

Resolved geodata:

latitude

longitude

country

region

city

precision

geom

Persistence point

Write to:

geo_locations

document_locations

Failure handling

If geocoding fails:

log unresolved location

continue with remaining items

allow future retry

Stage 7 — Geocoding Persistence
Responsibility

Store resolved geodata and connect documents to locations.

Inputs

geocoded location result

mention reference

document reference

Outputs

geolocation record

document-location link

Persistence point

Write to:

geo_locations

document_locations

Why this matters

This stage enables:

spatial queries

location-centric analytics

document-to-location navigation

Stage 8 — Analytics Rebuild
Responsibility

Transform operational data into BI-facing tables.

Inputs

Operational source tables:

documents

document_snapshots

location_mentions

geo_locations

document_locations

Outputs

BI tables such as:

bi_documents

bi_locations

bi_document_locations

Persistence point

Write to BI tables in Postgres.

Failure handling

If analytics rebuild fails:

keep operational data intact

log failure

allow retry without repeating upstream stages

Stage 9 — BigQuery Export
Responsibility

Publish BI tables to BigQuery.

Inputs

BI tables from Postgres

Outputs

exported BigQuery tables

Persistence point

Publication occurs outside the operational database.

Failure handling

If export fails:

do not discard BI tables

log export failure

allow export-only retry

Weekly Update Flow

The system must support a weekly incremental refresh.

Weekly sequence

identify new or changed documents

crawl those documents

create new snapshots where content changed

run extraction on those new snapshots

geocode new or unresolved normalized locations

rebuild BI tables

export BI tables to BigQuery

record/log completion

Design requirement

Weekly update must avoid unnecessary full recomputation whenever possible.

Partial Rerun Strategy

The pipeline must support partial reruns.

Examples:

Re-run crawl only

Use when source pages changed or PDF generation needs repair.

Re-run extraction only

Use when prompt/model changes and existing snapshots should be reprocessed.

Re-run geocoding only

Use when unresolved locations need another attempt or geocoding rules changed.

Rebuild analytics only

Use when BI schema changes.

Re-export only

Use when BigQuery export failed or downstream schema changed.

This capability is a core requirement of the architecture.

Observability Expectations

All stages should emit structured logs.

Minimum useful fields:

timestamp

service

stage

target

status

error when relevant

The pipeline should make it easy to answer:

which documents were processed

which snapshots failed extraction

which locations failed geocoding

whether BI export completed

Pipeline Constraints

The pipeline must preserve the following constraints:

extraction consumes cleaned text, not raw HTML directly

geocoding consumes normalized locations, not raw text spans

snapshots must be preserved even if extraction fails

BI generation must not mutate operational source data

export failures must not force recrawl/re-extraction

stage boundaries must stay explicit in code structure

MVP Implementation Guidance

In MVP, the logical stages may initially live inside one Python project.

That is acceptable.

However, code must still remain separated by module boundaries:

crawler module

extractor module

geocoder module

analytics module

orchestration module

This ensures later service separation remains possible without redesign.